<script src="libs/jquery/jquery.min.js"></script>
<script src="libs/glider/glider.min.js"></script>
<script src="libs/aos/dist/aos.js"></script>
<script src="js/index.js"></script>
<script src="js/menu.js"></script>
<script src="js/mail.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.1.7/dist/sweetalert2.all.min.js"></script>     

<script>
    Menu = new Menu({options: {openAndCloseWith: '.open', size:'lg', direction: 'right'}})
    Menu.init();
    AOS.init();
</script>
