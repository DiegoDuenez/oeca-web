<div class="banner">

    <div class="banner__logo">
       <a href="./"><img src="resources/img/logo-oeca.png" alt="OECA" title="OECA"></a>
    </div>

    <div class="banner__titulo" data-aos="zoom-in">
        INGENIERÍA <br>
        <span>INNOVADORA</span> 
    </div>

</div>