 
<div class="sidebar sidebar--fixed" id="sidebar-2-container">

    <div class="sidebar__menu" id="sidebar-menu-2">
        <button type="button" class="sidebar__menu-button open">
                <i class="fa-solid fa-bars"></i>
                MENÚ
        </button>
    </div>

    <div class="sidebar__social-media sidebar__social-media--d-none" >
        <a href="#" title="Facebook" class="up" target="blank"><i class="fa-brands fa-facebook"></i></a> 
        <a href="https://www.instagram.com/oeca_mx/?hl=en" title="Instagram" class="up" target="blank"><i class="fa-brands fa-instagram"></i></a> 
        <a href="https://api.whatsapp.com/send?phone=8717686693" target="blank" title="WhatsApp" class="up"><i class="fa-brands fa-whatsapp"></i></a> 
        <a href="mailto:proyectos@oeca.mx" title="Correo" class="up"><i class="fa-regular fa-envelope"></i></a> 
    </div>

</div>

<div class="sidebar" id="sidebar-1-container">

    <div class="sidebar__menu" id="sidebar-menu-1">
       <button type="button" class="sidebar__menu-button open">
            <i class="fa-solid fa-bars"></i>
            MENÚ
       </button>
    </div>

    <div class="sidebar__social-media">
        <a href="#" title="Facebook" class="up" target="blank"><i class="fa-brands fa-facebook"></i></a> 
        <a href="https://www.instagram.com/oeca_mx/?hl=en" title="Instagram" class="up" target="blank"><i class="fa-brands fa-instagram"></i></a> 
        <a href="https://api.whatsapp.com/send?phone=8717686693" target="blank" title="WhatsApp" class="up"><i class="fa-brands fa-whatsapp"></i></a> 
        <a href="mailto:proyectos@oeca.mx" title="Correo" class="up"><i class="fa-regular fa-envelope"></i></a> 
    </div>
</div>